import java.util.Random;

public class Rascacielos {
    private int totalPisos = 120;
    private int ascensores = 20;
    protected Ascensor[] listaAscensores;
    private boolean enEmergencia = false;

    public Rascacielos(int totalPisos, int ascensores) {
        this.totalPisos = totalPisos;
        this.ascensores = ascensores;
        listaAscensores = new Ascensor[ascensores];

        // Inicializa los ascensores en una matriz
        int[][] edificio = new int[totalPisos][ascensores];
        for (int i = 0; i < totalPisos; i++) {
            System.out.print("\n");
            for (int j = 0; j < ascensores; j++) {
                edificio[i][j] = 0;
                System.out.print("[" + edificio[i][j] + "]");
            }
        }
        System.out.println("\n");
        // Marca los pisos en los que se generan los ascensores con "[1]"
        for (int i = 0; i < ascensores; i++) {
            int pisoGeneracion = (int) (Math.random() * totalPisos); // Piso aleatorio
            edificio[pisoGeneracion][i] = 1;
            listaAscensores[i] = new Ascensor(pisoGeneracion); // Inicializa el Ascensor
        }

        System.out.println("\nEdificio con ascensores marcados:");
        for (int i = 0; i < totalPisos; i++) {
            System.out.print("\n");
            for (int j = 0; j < ascensores; j++) {
                System.out.print("[" + edificio[i][j] + "]");
            }
        }
    }

    public void cambiarEstadoEmergencia() {
        enEmergencia = !enEmergencia;
        if (enEmergencia) {
            // Apagar todos los ascensores excepto 10
            int ascensoresEnFuncionamiento = 0;
            for (int i = 0; i < ascensores; i++) {
                if (ascensoresEnFuncionamiento < 10) {
                    listaAscensores[i].activarFuncionamiento();
                    ascensoresEnFuncionamiento++;
                } else {
                    listaAscensores[i].apagar();
                }
            }
        } else {
            // Reactivar todos los ascensores
            for (Ascensor ascensor : listaAscensores) {
                ascensor.activarFuncionamiento();
            }
        }
    }

    public boolean estaEnEmergencia() {
        return enEmergencia;
    }

    public int getAscensores() {
        return ascensores;
    }

    public int getAscensoresEnFuncionamiento() {
        int funcionando = 0;
        for (Ascensor ascensor : listaAscensores) {
            if (ascensor.estaEnFuncionamiento()) {
                funcionando++;
            }
        }
        return funcionando;
    }
}
