import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        // Crear el rascacielos
        Rascacielos rascacielos = new Rascacielos(120, 20);

        // Crear la lista de trabajadores
        List<Trabajador> trabajadores = new ArrayList<>();
        // Generar trabajadores aleatorios
        trabajadores.add(new Trabajador(getRandomNumberInRange(1, 120), getRandomNumberInRange(1, 120)));
        trabajadores.add(new Trabajador(getRandomNumberInRange(1, 120), getRandomNumberInRange(1, 120)));
        trabajadores.add(new Trabajador(getRandomNumberInRange(1, 120), getRandomNumberInRange(1, 120)));

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                // Cambiar aleatoriamente el estado de emergencia
                if (getRandomNumberInRange(1, 10) <= 3) { // 30% de probabilidad
                    rascacielos.cambiarEstadoEmergencia();
                    System.out.println("El rascacielos está en estado de emergencia: " + rascacielos.estaEnEmergencia());
                }

                // Asignar ascensor a cada trabajador
                for (Trabajador trabajador : trabajadores) {
                    asignarAscensor(rascacielos, trabajador);
                }

                // Imprimir información de los trabajadores
                for (Trabajador trabajador : trabajadores) {
                    imprimirInformacionTrabajador(trabajador);
                }
                // Imprimir estado de emergencia y cantidad de ascensores disponibles
                System.out.println("Estado de emergencia: " + rascacielos.estaEnEmergencia());
                int ascensoresDisponibles = rascacielos.estaEnEmergencia() ? 10 : 20;
                System.out.println("Cantidad de ascensores disponibles: " + ascensoresDisponibles);
            }
        }, 0, 5000); // Cambiar el estado cada 5 segundos
    }

    public static void asignarAscensor(Rascacielos rascacielos, Trabajador trabajador) {
        if (rascacielos.estaEnEmergencia()) {
            // En estado de emergencia, asignar a los primeros 10 ascensores en la lista
            if (rascacielos.getAscensoresEnFuncionamiento() > 0 && rascacielos.getAscensoresEnFuncionamiento() <= 10) {
                trabajador.setAscensorAsignado(rascacielos.listaAscensores[rascacielos.getAscensores() - rascacielos.getAscensoresEnFuncionamiento()]);
            } else {
                System.out.println("Todos los ascensores están fuera de servicio en estado de emergencia.");
            }
        } else {
            // Lógica para asignar un ascensor al trabajador en estado normal
            Ascensor ascensorAsignado = encontrarAscensorCercano(rascacielos, trabajador.getPisoActual());
            trabajador.setAscensorAsignado(ascensorAsignado);
        }
    }

    private static Ascensor encontrarAscensorCercano(Rascacielos rascacielos, int pisoActual) {
        // Devuelve el ascensor mas cercano al piso especificado
        Ascensor ascensorCercano = null;
        int distanciaMinima = 120;

        for (int i = 0; i < rascacielos.getAscensores(); i++) {
            int distancia = Math.abs(rascacielos.listaAscensores[i].getPisoActual() - pisoActual);
            if (distancia < distanciaMinima) {
                distanciaMinima = distancia;
                ascensorCercano = rascacielos.listaAscensores[i];
            }
        }

        return ascensorCercano;
    }

    public static void imprimirInformacionTrabajador(Trabajador trabajador) {
        System.out.println("\n");
        System.out.println("--------------------------------------------------");
        System.out.println("Información del Trabajador:");
        System.out.println("Piso Actual: " + trabajador.getPisoActual());
        System.out.println("Piso Destino: " + trabajador.getPisoDestino());
        Ascensor ascensorAsignado = trabajador.getAscensorAsignado();
        if (ascensorAsignado != null) {
            System.out.println("Ascensor Asignado: Piso " + ascensorAsignado.getPisoActual());
        } else {
            System.out.println("Sin ascensor asignado.");
        }
        System.out.println();
    }

    public static int getRandomNumberInRange(int min, int max) {
        Random random = new Random();
        return random.nextInt((max - min) + 1) + min;
    }
}
