public class Trabajador {
    private int pisoActual;
    private int pisoDestino;
    private Ascensor ascensorAsignado;

    public Trabajador(int pisoActual, int pisoDestino) {
        this.pisoActual = pisoActual;
        this.pisoDestino = pisoDestino;
        this.ascensorAsignado = null; // Inicialmente no tiene un ascensor asignado
    }

    public int getPisoActual() {
        return pisoActual;
    }

    public int getPisoDestino() {
        return pisoDestino;
    }

    public Ascensor getAscensorAsignado() {
        return ascensorAsignado;
    }

    public void setAscensorAsignado(Ascensor ascensor) {
        this.ascensorAsignado = ascensor;
    }
}
