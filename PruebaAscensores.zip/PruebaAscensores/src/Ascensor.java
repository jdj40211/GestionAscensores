import java.util.*;

public class Ascensor {

    private int pisoActual;
    private List<Integer> destinos;
    private boolean enFuncionamiento;

    public Ascensor(int pisoGeneracion) {
        pisoActual = pisoGeneracion;
        destinos = new ArrayList<>();
        enFuncionamiento = true;
    }

    public void agregarDestino(int pisoDestino) {
        destinos.add(pisoDestino);
    }

    public void mover() {
        if (!destinos.isEmpty()) {
            int proximoDestino = destinos.get(0);
            if (pisoActual < proximoDestino) {
                pisoActual++;
            } else if (pisoActual > proximoDestino) {
                pisoActual--;
            }
            if (pisoActual == proximoDestino) {
                destinos.remove(0);
            }
        }
    }

    public boolean estaEnFuncionamiento() {
        return enFuncionamiento;
    }

    public void apagar() {
        enFuncionamiento = false;
    }

    public void activarFuncionamiento() {
        enFuncionamiento = true;
    }

    public int getPisoActual() {
        return pisoActual;
    }

    public List<Integer> getDestinos() {
        return destinos;
    }
}
